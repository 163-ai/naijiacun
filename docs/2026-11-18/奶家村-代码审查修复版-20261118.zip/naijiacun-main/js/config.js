// 奶家村 · 全站前端配置
// apiBase：Cloudflare Worker 的地址（部署后形如 https://naijiacun.xxx.workers.dev）。
// 留空 = 提名功能退回本机 localStorage 模式（只有提名者自己可见）。
window.NAIJIACUN_CONFIG = {
  apiBase: "",
  // 站点自带的聊天/TTS 透传代理（含 sharecode）。聊天、语音、首页三处共用。
  // 换域名或轮换 sharecode 时只改这里；未加载本文件的页面由各 JS 内的兜底常量保证可用。
  proxyBase: "https://naijiacun-chat.app.workbuddy.host/?sharecode=LJAS5NSXQO"
};
