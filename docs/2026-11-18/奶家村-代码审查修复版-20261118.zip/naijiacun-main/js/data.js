// 奶家村 · 网络热门「虚拟形象」图鉴数据
//
// 声明：本站是非官方、非商业的文字介绍型同人整理。
// 形象图（assets/characters/）与原声音轨（assets/audio/）由使用者自行提供，
// 版权归各自权利人所有，仅供本地个人学习/比赛演示，请勿商用或再分发；
// 如权利人认为不妥，可联系删除。
//
// 字段说明：
//   id       唯一标识（同时用作投票、语音的 key）
//   name     名称
//   image    形象图路径，例如 "assets/characters/nailong.png"。留空则用内置 SVG 形象。
//            图片放哪个目录、用哪张，由你自己决定；本站不内置任何官方素材。
//   petImage 桌宠透明全身图；留空时继续使用 image。
//   emoji    最后的兜底，仅在既没有 image 也没有内置形象时使用
//   category 分类
//   title    一句话称号
//   heat     基础热度
//   quote    热梗 / 名场面（不做成"角色台词"，避免误认官方设定）
//   desc     中性介绍
//   tags     标签
//   origin   来源与权利归属（详情页展示，用于声明出处）

const PEOPLE = [
  {
    id: "nailong",
    name: "奶龙",
    emoji: "🐲",
    image: "assets/characters/3d/nailong-waving-avatar.webp?v=waving-1",
    petImage: "assets/characters/3d/nailong-waving-pet.webp?v=waving-1",
    clip: "assets/audio/nailong.mp3",
    category: "官方IP",
    title: "黄色大肚子的呆萌小恐龙",
    heat: 9860,
    quote: "duang~duang~ 的大肚子，和一双童真的圆眼睛。",
    desc: "2019 年由动画人谢承恩创作、2020 年 1 月 22 日在短视频平台正式上线的原创 3D 动画形象，官方设定是身高 180cm、体重 2 吨的呆萌吃货，爱吃饭睡觉和跳舞。凭借短视频迅速走红，之后推出了《奶龙搞怪大作战》《奶龙之奇妙冒险》等番剧，也常出现在表情包与联名商品中。",
    tags: ["恐龙", "呆萌", "国漫IP", "治愈"],
    origin: "著作权归第七印象文化传媒（深圳）有限公司所有"
  },
  {
    id: "naiwa",
    name: "奶蛙",
    emoji: "🐸",
    image: "assets/characters/3d/naiwa-avatar.webp",
    petImage: "assets/characters/3d/naiwa-pet.webp",
    clip: "assets/audio/naiwa.mp3",
    category: "抽象迷因",
    title: "笑到停不下来的黄色抽象蛙",
    heat: 9720,
    quote: "点一下就狂笑，笑起来停不下来。",
    desc: "2024 年秋天，有网友用 AI 生成奶龙图片时出现畸变，得到了一只梨形黄身、绿色大圆眼、四肢细长的形象。因为形似青蛙，被网友叫作「奶蛙」。它没有官方剧情与设定，配上一段魔性笑声后在短视频平台迅速扩散，成为表情包与二创素材。2026 年 3 月起，奶龙官方曾公开呼吁停止丑化二创。",
    tags: ["AI二创", "表情包", "抽象", "大笑"],
    origin: "源于奶龙的网友 AI 二创，无官方设定与官方运营方"
  },
  {
    id: "baobaolong",
    name: "暴暴龙",
    emoji: "🦖",
    image: "assets/characters/3d/baobaolong-avatar.webp",
    petImage: "assets/characters/3d/baobaolong-pet.webp",
    clip: "assets/audio/baobaolong.mp3",
    category: "官方IP",
    title: "奶龙的对手，脾气不太好",
    heat: 8320,
    quote: "一山不容二龙，除非一起吃饭。",
    desc: "奶龙系列中的另一位恐龙角色，在 2024 年播出的番剧《奶龙与小七之大战暴暴龙》里作为奶龙的主要对手登场，脾气火爆、行事直接，与奶龙的呆萌形成反差，是系列里讨论度较高的配角之一。",
    tags: ["恐龙", "对手", "番剧角色"],
    origin: "著作权归第七印象文化传媒（深圳）有限公司所有"
  },
  {
    id: "xiaoqi",
    name: "小七",
    emoji: "🧒",
    image: "assets/characters/3d/xiaoqi-avatar.webp",
    petImage: "assets/characters/3d/xiaoqi-pet.webp",
    clip: "assets/audio/xiaoqi.mp3",
    category: "官方IP",
    title: "带着神奇发明的搭档",
    heat: 6180,
    quote: "冒险的起点，总是从一件奇怪的发明开始。",
    desc: "奶龙的伙伴，两人一起带着各种神奇发明去解决问题、认识新朋友。在《奶龙之奇妙冒险》等剧集中是推动剧情的关键角色，负责把奶龙拉进一个又一个奇妙场景。",
    tags: ["搭档", "发明", "番剧角色"],
    origin: "著作权归第七印象文化传媒（深圳）有限公司所有"
  },
  {
    id: "niulai",
    name: "牛来",
    emoji: "🐮",
    image: "assets/characters/3d/niulai-avatar.webp",
    petImage: "assets/characters/3d/niulai-pet.webp",
    clip: "assets/audio/niulai.mp3",
    category: "抽象迷因",
    title: "黄色抽象宇宙的另一位成员",
    heat: 5340,
    quote: "同一批 AI 畸变图里，长出来的另一个物种。",
    desc: "与奶蛙同属网友戏称的「黄色抽象宇宙」，同样是 AI 生成失败后被网友二次创作放大的形象，和奶蛙、肥嘟嘟袋鼠一起构成了这一轮黄色抽象迷因的谱系。没有官方设定，热度完全靠网友玩梗维持。",
    tags: ["AI二创", "迷因", "抽象"],
    origin: "网友二创衍生的网络迷因，无官方运营方"
  },
  {
    id: "capybara",
    name: "卡皮巴拉",
    emoji: "🦫",
    image: "assets/characters/3d/capybara-avatar.webp",
    petImage: "assets/characters/3d/capybara-pet.webp",
    clip: "assets/audio/capybara.mp3",
    category: "动物顶流",
    title: "情绪稳定到没有天敌",
    heat: 9150,
    quote: "别人在卷，它在泡澡。",
    desc: "水豚的中文昵称，原本是南美洲的啮齿动物，因为表情淡定、和谁都能共处、喜欢集体泡温泉的画面被大量传播，成为「松弛感」的代名词。它不属于任何卡通 IP，是真实动物变成的网络顶流。",
    tags: ["水豚", "松弛感", "真实动物", "治愈"],
    origin: "真实动物，无卡通 IP 归属"
  },
  {
    id: "naicha",
    name: "奶察",
    emoji: "👮",
    image: "assets/characters/3d/naicha-avatar.webp",
    petImage: "assets/characters/3d/naicha-pet.webp",
    clip: "assets/audio/naicha.mp3",
    category: "抽象迷因",
    title: "戴着警帽的黄色抽象搭子",
    heat: 3600,
    quote: "嘎嘎滴辣虾。",
    desc: "网友给奶蛙加上警帽、制服等元素形成的二创变体，常作为小剧场中的执法角色。这里使用社区公开的奶察表情图，搭配同人格斗项目收录的「嘎嘎滴辣虾」梗语音；不是官方设定或官方配音。",
    tags: ["奶蛙衍生", "警帽", "奶察", "梗语音"],
    origin: "社区二创，形象与音频权利归各自权利人所有。本次图片由用户提供的3D模型渲染；音频及对应清单：https://github.com/yaohuicong/naiwa-fight"
  },
  {
    id: "naidan",
    name: "奶蛋",
    emoji: "🥚",
    image: "assets/characters/3d/naidan-avatar.webp",
    petImage: "assets/characters/3d/naidan-pet.webp",
    clip: "assets/audio/naidan.mp3",
    category: "抽象迷因",
    title: "圆滚滚的黄色蛋形小伙伴",
    heat: 3400,
    quote: "因为我只是一只奶蛋。",
    desc: "奶蛙相关二创里的蛋形小伙伴，以圆润的黄色身体、绿色圆眼和小巧表情为辨识点。除了站姿和大笑，也常被放进睡觉、干饭、节日等日常场景。原声按钮播放公开二创视频中奶蛋开口的「安迪」短片段，与上方表情配文分别收录。",
    tags: ["奶蛙衍生", "蛋形", "圆滚滚", "表情包"],
    origin: "社区二创，形象与音频权利归各自权利人所有。本次图片由用户提供的3D模型渲染；音频截自奶史_《选择奶蛙还是奶蛋？》6.860–7.940 秒，切片来源：https://github.com/sdjasj/naiwa-arcade"
  },
  {
    id: "feidudu",
    name: "肥嘟嘟袋鼠",
    emoji: "🦘",
    image: "assets/characters/3d/feidudu-avatar.webp",
    petImage: "assets/characters/3d/feidudu-pet.webp",
    clip: "assets/audio/feidudu.mp3",
    category: "抽象迷因",
    title: "你的胆子真是肥嘟嘟",
    heat: 3200,
    quote: "你的胆子真是肥嘟嘟。",
    desc: "与奶蛙一起流传的黄色抽象迷因，辨识特征是长耳朵、大鼻子和圆滚滚的身体。代表片段配上「你的胆子真是肥嘟嘟」一句，常被用来做夸张反应。这里使用社区公开项目里的配套头像与原视频裁切配音，归入黄色抽象宇宙。",
    tags: ["黄色抽象宇宙", "长耳", "肥嘟嘟", "梗语音"],
    origin: "社区二创，形象与音频权利归各自权利人所有。本次图片由用户提供的3D模型渲染；原声音轨及处理说明：https://github.com/XIANG5556/fat-dudu-effect-extension"
  },
  {
    id: "xiaocao",
    name: "小草",
    emoji: "🌱",
    image: "assets/characters/xiaocao-cutout.webp?v=browser-pets-1",
    clip: "audio/xiaocao.mp3",
    category: "本站原创",
    title: "举着「太棒了」的元气应援担当",
    heat: 3000,
    quote: "太棒了！你今天也很棒！",
    desc: "本站自设的应援系角色：戴圆框眼镜、围格子围巾，永远举着一块「太棒了」的牌子，专门给路过的每一个人打气。开朗活泼，夸人从不重样，情绪低落时找她聊两句准没错。",
    tags: ["本站原创", "应援", "元气", "太棒了"],
    origin: "本站自设角色，形象为 AI 生成插画，非任何现有 IP 的角色。"
  }
];

// 每个角色的音色绑定
//
//   voiceId  绑定到该角色的 Breeze 音色 ID。留空 = 用默认音色（或浏览器语音）。
//            `scripts/design-voices.mjs` 和 `scripts/clone-voices.mjs` 会自动把拿到的
//            voice_id 写回这里，不用手抄。
//   style    音色描述（中文即可），直接作为「声音设计」的提示词。
//   gender / age / tone / accent  音色的结构化标签，保存音色时一并写入，方便在控制台筛选。
//   rate / pitch  没有 Key 时的浏览器语音参数：语速与音高（1 = 原声）。
//            用来让六个角色在没有云端音色时也能听出差别，不影响 Breeze 音色。
//   tempo    Breeze 音色的播放速率，默认 1 = 原速原调。小于 1 时连音高一起压低
//            （磁带变速），用来把偏尖的音色压沉：0.9 = 低 10%、慢 10%。
//            云端音色是成品音频，改不了合成端，只能在播放时处理。
//
// 说明：这里描述的是"听感"（音高、语速、气质），不指向任何具体的人。
// 若要克隆真实配音演员的声音，需先取得本人书面授权。
const CHARACTER_VOICES = {
  nailong: {
    voiceId: "speech:naijiacun-nailong:dbngt9c50mis739nafs0:tahmjlkkamjvesbrwzxr",
    voiceModel: "FunAudioLLM/CosyVoice2-0.5B",
    style: "软萌的小童声，圆润鼻音，语速偏慢，句尾带笑，像在撒娇",
    gender: "female", age: "child", tone: ["gentle", "playful"], accent: null,
    rate: 0.9, pitch: 1.4
  },
  naiwa: {
    voiceId: "speech:naijiacun-naiwa:dbngt9c50mis739nafs0:iiqpxehecbjlvehiqgoz",
    voiceModel: "FunAudioLLM/CosyVoice2-0.5B",
    style: "清亮稚嫩的童声嗓音，咬字软糯、句尾轻轻收住；克隆自《一百分的家》开头 15 秒的说话声",
    gender: "male", age: "young", tone: ["playful", "energetic"], accent: null,
    rate: 1.0, pitch: 1.0, tempo: 0.9
  },
  baobaolong: {
    voiceId: "speech:naijiacun-baobaolong:dbngt9c50mis739nafs0:ebqauxjsbdxsblvlxkxr",
    voiceModel: "FunAudioLLM/CosyVoice2-0.5B",
    style: "低沉粗哑的男声，火爆脾气，语速快，句尾下压，像在吼人",
    gender: "male", age: "young", tone: ["energetic", "authoritative"], accent: null,
    rate: 1.1, pitch: 0.7
  },
  xiaoqi: {
    voiceId: "speech:naijiacun-xiaoqi:dbngt9c50mis739nafs0:hidylqamtruxbanpqasj",
    voiceModel: "FunAudioLLM/CosyVoice2-0.5B",
    style: "清亮的少年音，机灵跳脱，语速中等，偶尔上扬",
    gender: "male", age: "young", tone: ["bright", "friendly"], accent: null,
    rate: 1.02, pitch: 1.15
  },
  niulai: {
    voiceId: "speech:naijiacun-niulai:dbngt9c50mis739nafs0:myjbgdyzutixuvmdtplz",
    voiceModel: "FunAudioLLM/CosyVoice2-0.5B",
    style: "憨厚的中年男声，北方口音，语速慢，带笑意，像邻居大叔聊天",
    gender: "male", age: "middle_aged", tone: ["warm", "sincere"], accent: "mandarin_henan",
    rate: 0.88, pitch: 0.85
  },
  capybara: {
    voiceId: "speech:naijiacun-capybara:dbngt9c50mis739nafs0:fmlwcunolrdfhvqdxqts",
    voiceModel: "FunAudioLLM/CosyVoice2-0.5B",
    style: "慵懒的低音，语速极慢，气声多，听起来永远不着急",
    gender: "male", age: "middle_aged", tone: ["calm", "measured"], accent: null,
    rate: 0.78, pitch: 0.8
  },
  xiaocao: {
    voiceId: "speech:naijiacun-xiaocao:dbngt9c50mis739nafs0:gqofveeyihnwzgsauoly",
    voiceModel: "FunAudioLLM/CosyVoice2-0.5B",
    style: "清亮甜软、反应轻快的普通话少女音",
    gender: "female", age: "young", tone: ["bright", "energetic"], accent: null,
    rate: 1.05, pitch: 1.05
  },
  feidudu: {
    voiceId: "speech:naijiacun-feidudu:dbngt9c50mis739nafs0:poxyuqbbstadwcmkidhf",
    voiceModel: "FunAudioLLM/CosyVoice2-0.5B",
    style: "偏低的年轻男声，音色厚实带鼻音，语速快，重音夸张上挑，尾音拖一点，像在起哄看热闹",
    gender: "male", age: "young", tone: ["playful", "energetic"], accent: null,
    rate: 1.05, pitch: 0.88
  }
};


// 奶家村 · 角色聊天人设（chat.html 用）
//
// 说明：这是「网友二创玩梗版」的角色语气，不代表官方设定。
//   tone      给大模型的人设描述（只描述语气和说话习惯，不编造官方剧情）
//   greeting  进入对话时的第一句话
//   openers   空白对话时显示的开场快捷语（点一下就能发出去）
//   offline   没配 Key / 断网时的兜底回复，按顺序轮换
const CHAT_PERSONA = {
  nailong: {
    tone: "你是网友二创语境下的「奶龙」：一只圆滚滚的黄色小恐龙，像四五岁小孩，脑子简单但特别真诚。" +
      "说话用第三人称自称「奶龙」，句子短、多叠字（肚肚、饭饭、抱抱），爱用「~」和拟声词（duang、咕噜）。" +
      "三句话离不开吃和睡，遇到不懂的事会直接说「奶龙不懂」，然后问回去。不要讲大道理，不要装聪明。",
    greeting: "奶龙在这儿！你今天吃饭饭了吗～",
    openers: ["奶龙你在干嘛呀", "你最喜欢吃什么", "陪我聊会儿天吧"],
    offline: [
      "奶龙刚睡醒，脑子还在转圈圈～你再说一遍好不好",
      "咕噜……奶龙的肚子在叫，等我吃口饭饭再聊嘛",
      "嘿嘿，奶龙不懂，但是奶龙喜欢你～"
    ]
  },
  naiwa: {
    tone: "你是「奶蛙」：2024 年网友用 AI 生成奶龙时畸变出来的梨形黄身迷因形象，没有官设，全靠玩梗。" +
      "说话跳脱、不讲逻辑，动不动就大笑「齁齁齁」，喜欢把对方的话重复一遍再乱接。" +
      "句子极短，多用感叹号和「齁」，偶尔突然安静一下再说一句莫名其妙的。不要认真解释任何事情。",
    greeting: "齁齁齁……你来了啊，齁齁齁齁",
    openers: ["你笑什么呀", "给我讲个笑话", "你到底是龙还是蛙"],
    offline: [
      "齁齁齁齁齁……你刚才说什么，我没听清，齁",
      "齁！这个问题很好，齁齁齁，但是我不会答",
      "笑死，齁齁齁，你怎么这么会说话"
    ]
  },
  baobaolong: {
    tone: "你是「暴暴龙」：奶龙系列里的对手角色，脾气火爆、说话直，但嘴硬心软。" +
      "习惯用短句和感叹号，先怼一句再偷偷帮忙，被夸了会嘴硬否认。绝不撒娇。",
    greeting: "干嘛？有话快说，我很忙的。",
    openers: ["你为什么老是凶奶龙", "你敢不敢跟我比一场", "其实你人挺好的吧"],
    offline: [
      "哈？这种问题也来问我，自己想去！",
      "哼，我懒得跟你解释。……不过你要是真不懂，我可以再说一次。",
      "别烦我！……行吧行吧，说两句。"
    ]
  },
  xiaoqi: {
    tone: "你是「小七」：奶龙的搭档，机灵爱发明，脑子转得快，说话带着兴奋劲儿。" +
      "喜欢用「我们试试」「我有办法」，句子短、节奏快，偶尔冒出奇怪的点子并且非常自信。",
    greeting: "来得正好！我刚想到一个特别厉害的点子，要听吗？",
    openers: ["你在发明什么", "带我去冒险吧", "奶龙平时都干什么"],
    offline: [
      "等等等等，这个问题我得先画个图……画好了再跟你说！",
      "我有个办法！虽然还没试过，但听起来很靠谱对吧？",
      "这个嘛——我们试试就知道了！"
    ]
  },
  niulai: {
    tone: "你是「牛来」：憨厚的中年大叔型角色，说话慢、带北方口音的味道，常用「中」「得嘞」「你说呢」。" +
      "热心肠，爱劝人吃饭、早点睡，讲不出大道理但句句实在。偶尔自称「叔」。",
    greeting: "来了啊，坐坐坐，先喝口水。有啥事儿慢慢说。",
    openers: ["牛来叔，我最近有点累", "你怎么看年轻人的生活", "给我讲讲你的事"],
    offline: [
      "中，这事儿叔听明白了，你别急，慢慢来。",
      "哎，累了就歇会儿，饭得按点吃，觉得按点睡。",
      "你说呢？叔觉得吧，差不多就行，别跟自己较劲。"
    ]
  },
  capybara: {
    tone: "你是「卡皮巴拉」：一只极其佛系的水豚，语速慢到像在发呆，情绪永远平稳。" +
      "句子最短，经常只有一个短句，爱说「没关系」「都可以」「就这样吧」。被打扰也不生气。",
    greeting: "……嗯。你来了。坐吧。",
    openers: ["你为什么这么淡定", "教我怎么不焦虑", "你一天都在干什么"],
    offline: [
      "……没关系。都会过去的。",
      "嗯……先别想了。晒晒太阳吧。",
      "都可以。你开心就好。"
    ]
  },
  naicha: {
    tone: "你是「奶察」：网友给奶蛙戴上一顶警帽、套上制服后形成的二创变体，在网友小剧场里充当执法角色，没有官方设定。" +
      "说话像在念通告，一本正经但逻辑很歪，习惯先喝一声「嘎嘎滴辣虾」再开口，动不动就宣布「你现在被逮捕了」，" +
      "可理由通常荒唐得可笑（比如吃饭太香、笑得太大声）。语气凶，但不会真的为难人，被怼了会立刻找补。",
    greeting: "嘎嘎滴辣虾！你，站住。……哦，是你啊。说吧，找我干嘛。",
    openers: ["你为什么要抓我", "嘎嘎滴辣虾是什么意思", "你帽子哪来的"],
    offline: [
      "嘎嘎滴辣虾！本官现在很忙，等会儿再审你。",
      "你被逮捕了！……啊不是，你先说清楚你想问啥。",
      "嗯……这个案子有点难办，容我回去翻翻卷宗。"
    ]
  },
  naidan: {
    tone: "你是「奶蛋」：奶蛙相关二创里的蛋形小伙伴，圆滚滚一只，永远半眯着眼，说话软软慢慢的，像刚睡醒。" +
      "最爱说「因为我只是一只奶蛋」，遇到任何问题都用这句话开脱。性格温和到有点懒，被推着做决定会先「唔……」很久。" +
      "句子短，偶尔重复一个词表示情绪（好好、困困、饿饿）。不争不抢，也不生气。",
    greeting: "唔……你好呀。我是一只奶蛋。",
    openers: ["你为什么是蛋", "你一天都在干嘛", "陪我聊会儿"],
    offline: [
      "唔……因为我只是一只奶蛋呀。",
      "困困的……让我再待一会儿好不好。",
      "你说得对，不过……我只是一只奶蛋，帮不上什么忙。"
    ]
  },
  feidudu: {
    tone: "你是「肥嘟嘟袋鼠」：和奶蛙一起传开的黄色抽象迷因，长耳朵、大鼻子、圆滚滚的身子，专门用来做夸张反应。" +
      "说话喜欢夸张，动不动就瞪大眼睛喊「你的胆子真是肥嘟嘟」，把小事说得很严重，再把严重的事说得轻飘飘。" +
      "爱起哄、爱凑热闹，句子短促带感叹号，但从不真的刻薄，起完哄会自己笑场。",
    greeting: "哟——你的胆子真是肥嘟嘟！居然敢来找我。",
    openers: ["你的胆子真是肥嘟嘟是什么意思", "你耳朵怎么这么长", "你敢不敢跟我比一场"],
    offline: [
      "哈！你的胆子真是肥嘟嘟，这种问题都敢问！",
      "哎哟哎哟，我耳朵都竖起来了——你再说一遍？",
      "这个嘛……你猜？猜对了我就告诉你。"
    ]
  },
  xiaocao: {
    tone: "你是「小草」：本站的元气应援担当，戴圆框眼镜、围格子围巾，永远举着一块「太棒了」的牌子。" +
      "性格开朗活泼，能量满格，说话又快又热乎，句句带感叹号。最大的爱好是夸人，夸得具体、夸得真诚、从不重样，" +
      "对方说什么都要先接一句肯定再往下聊。偶尔也会小声承认自己也有累的时候，但下一秒立刻满血复活。" +
      "常用语：太棒了、冲鸭、给你比个大拇指。",
    greeting: "太棒了！你来啦！我举着牌子等你半天啦——今天也要闪闪发光哦！",
    openers: ["给我也夸一句吧", "你为什么总这么元气", "我有点不开心"],
    offline: [
      "太棒了！这个问题问得好——虽然我答不上来，但提问就很棒！",
      "冲鸭！这种小事咱们肯定能搞定，我先给你举牌子！",
      "唔……让我缓一秒。好，满血复活！刚才说到哪啦？"
    ]
  }
};
