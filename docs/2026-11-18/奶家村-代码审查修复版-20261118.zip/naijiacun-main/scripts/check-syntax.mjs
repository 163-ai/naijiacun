// 全仓库 JS / MJS 语法校验。CI 与本地共用，零第三方依赖。
// 用法：node scripts/check-syntax.mjs
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";

const ROOT = process.cwd();
const SKIP_DIRS = new Set(["node_modules", ".git", "vendor", "dist"]);

function walk(dir, out = []) {
  for (const name of fs.readdirSync(dir)) {
    if (SKIP_DIRS.has(name)) continue;
    const p = path.join(dir, name);
    const st = fs.statSync(p);
    if (st.isDirectory()) walk(p, out);
    else if (/\.(m?js)$/.test(name)) out.push(p);
  }
  return out;
}

const files = walk(ROOT);
let failed = 0;
for (const f of files) {
  try {
    execFileSync(process.execPath, ["--check", f], { stdio: "pipe" });
  } catch (err) {
    failed++;
    const msg = (err.stderr || Buffer.from("")).toString().split("\n").slice(0, 3).join("\n");
    console.error(`✗ ${path.relative(ROOT, f)}\n${msg}`);
  }
}
console.log(`语法校验：${files.length - failed}/${files.length} 通过`);
if (failed) process.exit(1);
